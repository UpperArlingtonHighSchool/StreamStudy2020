import java.util.ArrayList;

public class OneVarStats{
 static double[] averages;
 public static void average(ArrayList<DataPoint> data){
  averages = new double[14];
  int[] counters = new int[14];
  for(int i = 0; i<16; i++) {
   for(int j = 0; j<data.size(); j++) {
    switch(i) {
     case 0:
      if(data.get(j).getFlowRate()!=-99) {
       averages[i]+=data.get(j).getFlowRate();
       counters[i]++;
      }
      break;
     case 1:
      if(data.get(j).getTurbid()!=-99) {
       averages[i]+=data.get(j).getTurbid();
       counters[i]++;
      }
      break;
     case 2:
      if(data.get(j).getTemp()!=-99) {
       averages[i]+=data.get(j).getTemp();
       counters[i]++;
      }
      break;
     case 3:
      if(data.get(j).getTDS()!=-99) {
       averages[i]+=data.get(j).getTDS();
       counters[i]++;
      }
      break;
     case 4:
      if(data.get(j).getConduct()!=-99) {
       averages[i]+=data.get(j).getConduct();
       counters[i]++;
      }
      break;
     case 5:
      if(data.get(j).getSalinity()!=-99) {
       averages[i]+=data.get(j).getSalinity();
       counters[i]++;
      }
      break;
     case 6:
      if(data.get(j).getHardness()!=-99) {
       averages[i]+=data.get(j).getHardness();
       counters[i]++;
      }
      break;
     case 7:
      if(data.get(j).getTotalCl()!=-99) {
       averages[i]+=data.get(j).getTotalCl();
       counters[i]++;
      }
      break;
     case 8:
      if(data.get(j).getFreeCl()!=-99) {
       averages[i]+=data.get(j).getFreeCl();
       counters[i]++;
      }
      break;
     case 9:
      if(data.get(j).getAlk()!=-99) {
       averages[i]+=data.get(j).getAlk();
       counters[i]++;
      }
      break;
     case 10:
      if(data.get(j).getPH()!=-99) {
       averages[i]+=data.get(j).getPH();
       counters[i]++;
      }
      break;
     case 11:
      if(data.get(j).getNitrate()!=-99) {
       averages[i]+=data.get(j).getNitrate();
       counters[i]++;
      }
      break;
     case 12:
      if(data.get(j).getNitrite()!=-99) {
       averages[i]+=data.get(j).getNitrite();
       counters[i]++;
      }
      break;
     case 13:
      if(data.get(j).getPhosphate()!=-99) {
       averages[i]+=data.get(j).getPhosphate();
       counters[i]++;
      }
      break;
    }
   }
  }
  for(int i = 0; i<14; i++) {
   averages[i] = averages[i]/counters[i];
  }
 }
 public double getAverageFlowRate() {
  return averages[0];
 }
 public double getAverageTurbid() {
  return averages[1];
 }
 public double getAverageTemp() {
  return averages[2];
 }
 public double getAverageTDS() {
  return averages[3];
 }
 public double getAverageConduct() {
  return averages[4];
 }
 public double getAverageSalinity() {
  return averages[5];
 }
 public double getAverageHardness() {
  return averages[6];
 }
 public double getAverageTotalCl() {
  return averages[7];
 }
 public double getAverageFreeCl() {
  return averages[8];
 }
 public double getAverageAlk() {
  return averages[9];
 }
 public double getAveragePH() {
  return averages[10];
 }
 public double getAverageNitrate() {
  return averages[11];
 }
 public double getAverageNitrite() {
  return averages[12];
 }
 public double getAveragePhosphate() {
  return averages[13];
 }
}